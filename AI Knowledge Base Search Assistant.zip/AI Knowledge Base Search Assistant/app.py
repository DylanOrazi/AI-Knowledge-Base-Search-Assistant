from pathlib import Path
import tkinter as tk
from tkinter import scrolledtext

from src.document_loader import load_knowledge_base
from src.search_engine import semantic_search_documents
from src.answer_generator import generate_grounded_answer
from datetime import datetime
from tkinter import filedialog


# -----------------------------
# Load Knowledge Base
# -----------------------------

base_folder = Path(__file__).resolve().parent
knowledge_base_folder = base_folder / "data" / "knowledge_base"

documents = load_knowledge_base(knowledge_base_folder)

search_history = []
session_log = []

def get_confidence_label(score):
    if score >= 0.70:
        return "High"
    elif score >= 0.50:
        return "Moderate"
    elif score >= 0.30:
        return "Low"
    else:
        return "Very Low"


def get_article_title(content, filename):
    first_line = content.splitlines()[0].strip()

    if first_line.lower().startswith("title:"):
        return first_line.split(":", 1)[1].strip()

    return filename


def update_history_display():
    history_listbox.delete(0, tk.END)

    recent_items = search_history[-5:]

    for item in reversed(recent_items):
        display_text = (
            f"{item['query']} -> "
            f"{item['filename']} "
            f"({item['score']:.1%})"
        )

        history_listbox.insert(tk.END, display_text)

def export_current_result():
    content = results_box.get("1.0", tk.END).strip()

    if not content:
        return

    file_path = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Text Files", "*.txt")],
        title="Export Search Result"
    )

    if not file_path:
        return

    with open(file_path, "w", encoding="utf-8") as file:
        file.write("AI Knowledge Base Search Assistant\n")
        file.write("=" * 40 + "\n\n")
        file.write(content)


def export_session_log():
    if not session_log:
        return

    file_path = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Text Files", "*.txt")],
        title="Export Session Log"
    )

    if not file_path:
        return

    with open(file_path, "w", encoding="utf-8") as file:
        file.write("AI Knowledge Base Search Assistant - Session Log\n")
        file.write("=" * 50 + "\n\n")

        for item in session_log:
            file.write(f"Time: {item['time']}\n")
            file.write(f"Question: {item['query']}\n")
            file.write(f"Best Match: {item['filename']}\n")
            file.write(f"Relevance Score: {item['score']:.1%}\n")
            file.write("-" * 50 + "\n")


def perform_search():
    query = search_entry.get().strip()

    if not query:
        results_box.configure(state="normal")
        results_box.delete("1.0", tk.END) 
        results_box.insert(
            "1.0",
            "Please enter a question before searching the knowledge base."
        )
        results_box.configure(state="disabled")
        return

    selected_category = category_var.get()

    if selected_category == "ALL":
        filtered_documents = documents
    else:
        filtered_documents = [
            document 
            for document in documents
            if document["category"] == selected_category
        ]

    if not filtered_documents:
        results_box.configure(state="normal")
        results_box.delete("1.0", tk.END)
        results_box.insert(
            "1.0",
            "No knowledge base articles are available in this category."
        )
        results_box.configure(state="disabled")
        return

    try:
        results = semantic_search_documents(
            query,
            filtered_documents
        )

    except Exception as error:
        results_box.configure(state="normal")
        results_box.delete("1.0", tk.END)
        results_box.insert(
            "1.0",
            "An error occurred while searching the knowledge base.\n\n"
            f"Details: {error}"
        )
        results_box.configure(state="disabled")
        return

    if not results:
        results_box.configure(state="normal")
        results_box.delete("1.0", tk.END)
        results_box.insert(
            "1.0",
            "The search could not return any results."
        )
        results_box.configure(state="disabled")
        return

    best_result = results[0]

    source_name = get_article_title(
        best_result["content"],
        best_result["filename"]
    )

    confidence = get_confidence_label(best_result["score"])

    results_box.configure(state="normal")
    results_box.delete("1.0", tk.END)

    if best_result["score"] < 0.25:
        results_box.insert(
            "1.0",
            "No strong knowledge base match was found.\n\n"
            "Try rephrasing the question, choosing a different category, "
            "or adding more specific details."
        )

    else:
        search_history.append({
            "query": query,
            "filename": best_result["filename"],
            "score": best_result["score"]
        })

        session_log.append({
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "query": query,
            "filename": best_result["filename"],
            "score": best_result["score"]
        })

        update_history_display()

        ai_answer = generate_grounded_answer(
            query,
            best_result["content"]
        )

        result_text = (
            f"AI Answer:\n"
            f"{ai_answer}\n\n"
            f"Source: {source_name} ({best_result['filename']})\n\n"
            f"Best Match: {best_result['filename']}\n"
            f"Relevance Score: {best_result['score']:.1%}\n\n"
            f"Confidence: {confidence}\n\n" 
            f"Source Article:\n" 
            f"{best_result['content']}"
        )

        result_text += "\n\nTop Matches:\n"

        for index, result in enumerate(results[:3], start=1):
            result_text += (
                f"{index}. {result['filename']} "
                f"({result['score']:.1%})\n"
            )

        results_box.insert("1.0", result_text)

    results_box.configure(state="disabled")


# -----------------------------
# Main Window
# -----------------------------

root = tk.Tk()
root.title("AI Knowledge Base Search Assistant")
root.geometry("900x620")
root.minsize(760, 520)

root.configure(bg="#161B22")

# -----------------------------
# Header
# -----------------------------

header_frame = tk.Frame(
    root,
    bg="#161B22",
    height=110
)

header_frame.pack(fill="x")
header_frame.pack_propagate(False)

title_label = tk.Label(
    header_frame,
    text="AI Knowledge Base Search Assistant",
    font=("Segoe UI", 22, "bold"),
    bg="#161B22",
    fg="white"
)

title_label.pack(
    anchor="w",
    padx=30,
    pady=(22, 3)
)

subtitle_label = tk.Label(
    header_frame,
    text="Search technical knowledge using natural-language questions.",
    font=("Segoe UI", 10),
    bg="#161B22",
    fg="#8B949E"
)

subtitle_label.pack(
    anchor="w",
    padx=30
)

# -----------------------------
# Main Content
# -----------------------------

main_frame = tk.Frame(
    root,
    bg="#161B22"
)

main_frame.pack(
    fill="both",
    expand=True,
    padx=30,
    pady=25
)


# Search Section

search_label = tk.Label(
    main_frame,
    text="Ask a Question",
    font=("Segoe UI", 11, "bold"),
    bg="#161B22",
    fg="#F0F6FC"
)

search_label.pack(anchor="w")

search_frame = tk.Frame(
    main_frame,
    bg="#eef2f7"
)

search_frame.pack(
    fill="x",
    pady=(8, 20)
)

category_frame = tk.Frame(
    main_frame,
    bg="#161B22"
)

category_frame.pack(
    fill="x",
    pady=(0, 10)
)

category_label = tk.Label(
    category_frame,
    text="Category:",
    font=("Segoe UI", 10, "bold"),
    bg="#161B22",
    fg="#F0F6FC"
)

category_label.pack(
    side="left",
    padx=(0, 10)
)

category_var = tk.StringVar(value="All")

category_menu = tk.OptionMenu(
    category_frame,
    category_var,
    "All",
    "Wi-Fi",
    "Printing",
    "Microsoft Teams",
    "MFA",
    "Password / Account"
)

category_menu.configure(
    font=("Segoe UI", 9),
    bg="#21262D",
    fg="#F0F6FC",
    activebackground="#2EA043",
    activeforeground="white",
    relief="flat",
    highlightthickness=0
)

category_menu["menu"].configure(
    bg="#21262D",
    fg="#F0F6FC"
)

category_menu.pack(side="left")

search_entry = tk.Entry(
    search_frame,
    font=("Segoe UI", 11),
    bg="#0D1117",
    fg="#F0F6FC",
    insertbackground="#F0F6FC",
    relief="solid",
    bd=1
)

search_entry.pack(
    side="left",
    fill="x",
    expand=True,
    ipady=8
)

search_button = tk.Button(
    search_frame,
    text="Search Knowledge Base",
    font=("Segoe UI", 10, "bold"),
    bg="#2EA043",
    fg="white",
    activebackground="#3FB950",
    activeforeground="white",
    relief="flat",
    cursor="hand2",
    padx=18,
    pady=8,
    command=perform_search
)

search_button.pack(
    side="left",
    padx=(12, 0)
)


# Results Section

results_label = tk.Label(
    main_frame,
    text="Search Results",
    font=("Segoe UI", 11, "bold"),
    bg="#161B22",
    fg="#F0F6FC"
)

results_label.pack(anchor="w")

results_frame = tk.Frame(
    main_frame,
    bg="#161B22",
    height=280
)

results_frame.pack(
    fill="x",
    pady=(8, 10)
)

results_frame.pack_propagate(False)

results_box = scrolledtext.ScrolledText(
    results_frame,
    height=18,
    font=("Segoe UI", 10),
    bg="#0D1117",
    fg="#F0F6FC",
    insertbackground="#F0F6FC", 
    wrap="word",
    relief="solid",
    bd=1,
    padx=12,
    pady=12
)

results_box.pack(
    fill="x",
    expand=True
)

history_frame = tk.Frame(
    main_frame,
    bg="#161B22"
)

history_frame.pack(
    fill="x",
    pady=(5, 10)
)

history_label = tk.Label(
    main_frame,
    text="Recent Searches",
    font=("Segoe UI", 11, "bold"),
    bg="#161B22",
    fg="#F0F6FC"
)

history_label.pack(
    anchor="w",
    pady=(0, 6)
)

history_listbox = tk.Listbox(
    main_frame,
    height=3,
    font=("Segoe UI", 9),
    bg="#0D1117",
    fg="#F0F6FC",
    selectbackground="#2EA043",
    selectforeground="white",
    relief="solid",
    bd=1
)

history_listbox.pack(
    fill="x",
)

results_box.insert(
    "1.0",
    "Enter a question above to search the knowledge base."
)

results_box.configure(state="disabled")

export_frame = tk.Frame(
    main_frame,
    bg="#161B22"
)

export_frame.pack(
    fill="x",
    pady=(5, 10)
)

export_result_button = tk.Button(
    export_frame,
    text="Export Current Result",
    command=export_current_result,
    bg="#21262D",
    fg="#F0F6FC",
    activebackground="#2EA043",
    activeforeground="white",
    relief="flat",
    cursor="hand2",
    padx=12,
    pady=7
)

export_result_button.pack(
    side="left",
    padx=(0, 10)
)

export_log_button = tk.Button(
    export_frame,
    text="Export Session Log",
    command=export_session_log,
    bg="#21262D",
    fg="#F0F6FC",
    activebackground="#2EA043",
    activeforeground="white",
    relief="flat",
    cursor="hand2",
    padx=12,
    pady=7
)

export_log_button.pack(side="left")

# -----------------------------
# Status Bar
# -----------------------------

status_text = f"{len(documents)} knowledge base documents loaded"

status_label = tk.Label(
    root,
    text=status_text,
    font=("Segoe UI", 9),
    bg="#21262D",
    fg="#8B949E",
    anchor="w",
    padx=15,
    pady=7
)

status_label.pack(
    fill="x",
    side="bottom"
)


# -----------------------------
# Start Application
# -----------------------------

search_entry.focus()

search_entry.bind(
    "<Return>",
    lambda event: perform_search()
)

root.mainloop()

