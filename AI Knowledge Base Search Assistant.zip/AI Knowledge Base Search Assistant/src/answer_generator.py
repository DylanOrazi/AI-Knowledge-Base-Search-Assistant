from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

MODEL_NAME = "google/flan-t5-small"

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

model = AutoModelForSeq2SeqLM.from_pretrained(
    MODEL_NAME
)


def extract_source_fallback(context):
    lines = [
        line.strip()
        for line in context.splitlines()
        if line.strip()
    ]

    lines = [
        line
        for line in lines
        if not line.lower().startswith("title:")
    ]

    if not lines:
        return (
            "There is not enough information in the knowledge base "
            "to answer this question."
        )

    selected = lines[:3]

    if len(selected) == 1:
        return f"Start by checking this: {selected[0]}"

    elif len(selected) == 2:
        return (
            f"Start by checking the following. {selected[0]} "
            f"Then, {selected[1][0].lower() + selected[1][1:]}"
        )

    else:
        return (
            f"Start by checking the following. {selected[0]} "
            f"Next, {selected[1][0].lower() + selected[1][1:]} "
            f"If the issue continues, {selected[2][0].lower() + selected[2][1:]}"
        )


def is_bad_generated_answer(answer):
    cleaned = answer.strip().lower()

    if len(cleaned) < 15:
        return True

    words = cleaned.split()

    if len(words) >= 8:
        unique_ratio = len(set(words)) / len(words)

        if unique_ratio < 0.50:
            return True

    if cleaned.count("no") >= 3:
        return True

    if cleaned.startswith("no.") or cleaned.startswith("yes."):
        return True

    half = len(words) // 2

    if half >= 3:
        first_half = " ".join(words[:half])
        second_half = " ".join(words[half:half * 2])

        if first_half == second_half:
            return True

    return False


def generate_grounded_answer(question, context):
    prompt = (
        "You are a technical support assistant. "
        "Answer the user's question using only the knowledge base context below. "
        "Give a helpful answer in 1 to 3 complete sentences. "
        "Do not answer with only yes or no. "
        "Do not invent information that is not in the context. "
        "If the context does not contain enough information, say: "
        "'There is not enough information in the knowledge base to answer this question.'\n\n"
        f"User Question: {question}\n\n"
        f"Knowledge Base Context:\n{context}\n\n"
        "Helpful Answer:"
    )

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=512
    )

    outputs = model.generate(
        **inputs,
        max_new_tokens=120,
        min_new_tokens=15,
        do_sample=False
    )

    answer = tokenizer.decode(
        outputs[0],
        skip_special_tokens=True
    ).strip()

    if is_bad_generated_answer(answer):
        return extract_source_fallback(context)

    lower_answer = answer.lower()
    lower_context = context.lower()

    if (
        "not possible" in lower_answer
        and "approve a sign-in" in lower_context
    ):
        return extract_source_fallback(context)

    return answer