import re 

from sentence_transformers import SentenceTransformer, util


def normalize_text(text):
    text = text.lower()

    words = re.findall(r"\b\w+\b", text)

    return words 


def search_documents(query, documents):
    query_words = set(normalize_text(query))

    results = []

    for document in documents:
        document_words = set(normalize_text(document["content"]))

        matching_words = query_words.intersection(document_words)

        score = len(matching_words)

        results.append({
            "filename": document["filename"],
            "content": document["content"],
            "score": score
        })

        results.sort(
            key=lambda result: result["score"], 
            reverse=True 
        )

        return results

    
semantic_model = SentenceTransformer("all-MiniLM-L6-v2")

def semantic_search_documents(query, documents):
    if not documents:
        return []

    document_texts = [
        document["content"]
        for document in documents
    ]

    query_embedding = semantic_model.encode(
        query,
        convert_to_tensor=True
    )

    document_embeddings = semantic_model.encode(
        document_texts,
        convert_to_tensor=True 
    )

    similarity_scores = util.cos_sim(
        query_embedding,
        document_embeddings
    )[0]

    results = []

    for index, document in enumerate(documents):
        score = float(similarity_scores[index])

        results.append({
            "filename": document["filename"],
            "content": document["content"],
            "score": score
        })

    results.sort(
        key=lambda result: result["score"],
        reverse=True
    )

    return results