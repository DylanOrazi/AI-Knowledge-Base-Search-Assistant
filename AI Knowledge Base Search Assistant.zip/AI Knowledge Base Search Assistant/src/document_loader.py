from pathlib import Path


def load_knowledge_base(folder_path):
    documents = []

    knowledge_base_path = Path(folder_path)
    text_files = list(knowledge_base_path.glob("*.txt"))

    for file_path in text_files:
        content = file_path.read_text(encoding="utf-8").strip()

        category_map = {
            "wifi_troubleshooting.txt": "Wi-Fi",
            "printer_troubleshooting.txt": "Printing",
            "microsoft_teams_audio.txt": "Microsoft Teams",
            "mfa_setup.txt": "MFA",
            "password_reset.txt": "Password / Account"
        }

        documents.append({
            "filename": file_path.name,
            "content": content,
            "category": category_map.get(file_path.name, "Other")
        })

    return documents